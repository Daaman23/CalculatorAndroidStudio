package com.example.assignment2_200380633;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private Button zero;
    private Button one;
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine;
    private Button add;
    private Button equal;
    private Button sub;
    private Button mul;
    private Button div;
    private Button dec;
    private Double val1,val2;
    private final char ADDITION = '+';
    private final char SUBTRACTION = '-';
    private final char MULTIPLICATION = '*';
    private final char DIVISION = '/';
    private char ACTION;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        one = findViewById(R.id.btn1);
        two = findViewById(R.id.btn2);
        three = findViewById(R.id.btn3);
        four = findViewById(R.id.btn3);
        five = findViewById(R.id.btn5);
        six = findViewById(R.id.btn6);
        seven = findViewById(R.id.btn7);
        eight = findViewById(R.id.btn8);
        nine = findViewById(R.id.btn9);
        zero = findViewById(R.id.btn0);
        mul = findViewById(R.id.btnMul);
        div = findViewById(R.id.btnDiv);
        add = findViewById(R.id.btnAdd);
        sub = findViewById(R.id.btnSub);
        dec = findViewById(R.id.btnDeci);
        equal = findViewById(R.id.btnEqual);
        textView = findViewById(R.id.tvResult);


        one.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("1");
                }else{
                    textView.setText(textView.getText().toString() + "1");
                }
            }
        }));



        two.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("2");
                }else{
                    textView.setText(textView.getText().toString() + "2");
                }
            }
        }));
        three.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("3");
                }else{
                    textView.setText(textView.getText().toString() + "3");
                }
            }
        }));
        four.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("4");
                }else{
                    textView.setText(textView.getText().toString() + "4");
                }
            }
        }));
        five.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("5");
                }else{
                    textView.setText(textView.getText().toString() + "5");
                }
            }
        }));
        six.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("6");
                }else{
                    textView.setText(textView.getText().toString() + "6");
                }
            }
        }));
        seven.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("7");
                }else{
                    textView.setText(textView.getText().toString() + "7");
                }
            }
        }));
        eight.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("8");
                }else{
                    textView.setText(textView.getText().toString() + "8");
                }
            }
        }));
        nine.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(textView.getText().equals("Error")) {
                    textView.setText("9");
                }else{
                    textView.setText(textView.getText().toString() + "9");
                }
            }
        }));
        dec = (Button) findViewById(R.id.btnDeci);
        dec.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!textView.getText().toString().contains(".")) {
                    String val = textView.getText().toString();
                    textView.setText(val + ".");
                }
            }
        }));


        add.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView.setText("Error");
                }else {
                    ACTION= ADDITION;
                    val1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));
        sub.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    ACTION= SUBTRACTION;
                    val1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));
        mul.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView .setText("Error");
                }else {
                    ACTION= MULTIPLICATION;
                    val1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));
        div.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textView.getText().length() == 0){
                    textView.setText("Error");
                }else {
                    ACTION=DIVISION;
                    val1 = Double.parseDouble(textView.getText().toString());
                    textView.setText("");
                }
            }
        }));

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(val1!=0.0F){
                    val2 = Double.parseDouble(textView.getText().toString());
                    switch (ACTION){
                        case ADDITION:
                            textView.setText(String.valueOf(val1+val2));
                            break;
                        case SUBTRACTION:
                            textView.setText(String.valueOf(val1-val2));
                            break;
                        case MULTIPLICATION:
                            textView.setText(String.valueOf(val1*val2));
                            break;
                        case DIVISION:
                            textView.setText(String.valueOf(val1/val2));
                            break;
                        default:
                            textView.setText("Error");
                            break;
                    }
                }
            }
        });



    }
}
